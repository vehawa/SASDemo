#!/bin/bash
#content is password-management related


#handy way to generate a password of varying length using /dev/urandom
#taken from: https://unix.stackexchange.com/questions/230673/how-to-generate-a-random-string
#$1=length of new password, defaults to 10
#example call: myPass=$(getNewPassword 10) -> then you could use $myPass to get use new password of length 10
getNewPassword()
{
    local result=$(head /dev/urandom | env LC_CTYPE=C tr -dc A-Za-z0-9 | head -c${1-10})
    echo $result
}


#handy way to generate a password of varying length using /dev/urandom
#taken from: https://unix.stackexchange.com/questions/230673/how-to-generate-a-random-string
#this includes owasp special char list, minus a couple troublesome things like double quote: https://www.owasp.org/index.php/Password_special_characters
#$1=length of new password, defaults to 14
#example call: myPass=$(getNewPassword 16) -> then you could use $myPass to get use new password of length 16
getNewComplexPassword()
{
	#default to something divisble evenly by 4
	local totalLength=${1-16}

	#upper, lower, digit, special
	local partCount=4

	#assign counts and figure remainder, if any
	local remainder=$(( totalLength % partCount ))
	local upperCount=$(( totalLength / partCount ))
	local lowerCount=$(( totalLength / partCount ))
	local digitCount=$(( totalLength / partCount ))

	if [ $remainder == 0 ]; then
		local specialCount=$(( totalLength / partCount ))
	else
		local specialCount=$remainder
	fi

	#get each piece
	local result=$(head /dev/urandom | env LC_CTYPE=C tr -dc 'A-Z' | head -c$upperCount)
	result+=$(head /dev/urandom | env LC_CTYPE=C tr -dc 'a-z' | head -c$lowerCount)
	result+=$(head /dev/urandom | env LC_CTYPE=C tr -dc '0-9' | head -c$digitCount)
	result+=$(head /dev/urandom | env LC_CTYPE=C tr -dc '!#$%&()*+,-.:;<=>?@[]^_{|}' | head -c$specialCount)
    
	#scramble a the result so it's less predictable
    scrambleString $result
}


#$1: string to scramble
#https://stackoverflow.com/questions/26326286/bash-scramble-characters-contained-in-a-string
#example: scrambled=$(scrambleString abc123)
scrambleString() {
    local a=$1 i
    local scrambled=
			while((${#a})); do
				((i=RANDOM%${#a}))
				scrambled+=${a:i:1}
				a=${a::i}${a:i+1}
			done
	echo $scrambled
}
