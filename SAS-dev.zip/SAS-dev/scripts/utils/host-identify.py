import boto3
import os
import sys
import fileinput
import argparse
from dotenv import load_dotenv, find_dotenv


def parse_args():
    """ Parse command line args, return args object. """
    parser = argparse.ArgumentParser(description="SailPoint target.properties builder")
    parser.add_argument('--customer', '-c', action='store',
                        default=os.getenv('CUSTOMER'),
                        help='Name of customer')
    parser.add_argument('--environment', '-e', action='store',
                        dest='env', default=os.getenv('ENV'),
                        help='Name of environment for customer')
    parser.add_argument('--role', action='store',
                        default=os.getenv('AWS_CUSTOMER_ROLE'),
                        help='AWS IAM role to assume')
    parser.add_argument('--profile', '-p', action='store',
                        help='AWS credentials profile to use')
    parser.add_argument('--tag', '-t', action='store',
                        default='type', dest='tag',
                        help='Host type tag name')
    parser.add_argument('--region', '-r', action='store',
                        default=os.getenv('AWS_DEFAULT_REGION'),
                        help='AWS region for customer environment')
    parser.add_argument('--file', '-f', action='store',
                        dest='file', help='File to output')

    # get the rest as list of args.
    parser.add_argument('cmd', action='store', nargs=argparse.REMAINDER)

    args = parser.parse_args()

    return args

def main():

  env_path = 'target.env'
  load_dotenv(dotenv_path=env_path)
  args = parse_args()
  if args.file:
      editMode = 1 
      print("Edit mode enabled!")
      fileToEdit = args.file
  else :
      editMode = 0 
      print("Not editing files today...")
  if args.env:
    env = args.env
  else:
    print("No environment defined")
    exit(1)

  try:
    if(os.environ['AWS_CUSTOMER_ROLE']):
      stsmode = True
      print("Using STS Mode...")
  except:
      stsmode = False
      print("In non-STS Mode...")

  # determine if we should run in STS mode or native mode...
  if(stsmode):
    try:
      sts = boto3.client( 'sts' )
      stsResponse = sts.assume_role(
        RoleArn=os.environ['AWS_CUSTOMER_ROLE'],
        RoleSessionName='mysesh',
        DurationSeconds=3600,
      )

      credentials=stsResponse['Credentials']

      client = boto3.client('ec2',     
          aws_access_key_id=credentials['AccessKeyId'],
          aws_secret_access_key=credentials['SecretAccessKey'],
          aws_session_token=credentials['SessionToken'],)
      print("Entered STS Mode!")

    except:
        print("BOTO3 Failure in STS mode: ", sys.exc_info()[0])
        sys.exit(1)
  else:
    try:
        client = boto3.client(
            'ec2'
        )
    except:
        print("BOTO3 Failure in base mode: ", sys.exc_info()[0])
        sys.exit(1)

  tagFilter="tag:"+args.tag
  uiFilter = [{
    'Name':tagFilter,
    'Values': ['ui']},
    {'Name':'tag:Environment',
    'Values':[env]}]

  uiInstances = client.describe_instances(Filters=uiFilter)
  for uiInstance in uiInstances['Reservations'] :
      print(uiInstance['Instances'][0]['PrivateDnsName'], "- ui host")

  taskFilter = [{
     'Name':tagFilter,
     'Values': ['task']},
    {
     'Name':'tag:Environment',
     'Values':[env]}]

  taskInstances = client.describe_instances(Filters=taskFilter)
  for taskInstance in taskInstances['Reservations'] :
      print(taskInstance['Instances'][0]['PrivateDnsName'], "- task host")
  
  # check for instance counts - if both ui & task are 0, then die
  if len(uiInstances['Reservations']) == 0 and len(taskInstances['Reservations']) == 0:
    print("FATAL:  No Task or UI Servers found.")
    exit(1)
  
  # Below is edit mode related, if we have it set to false then exit 0
  if editMode != 1 :
    sys.exit(0)

  # build the strings
  taskStr = "%%TASK_HOSTS%%="
  uiStr = "%%UI_HOSTS%%="
  devSakStr = "%%DEVSAK_SERVER_MAP%%="
  
  for taskInstance in taskInstances['Reservations'] :
      taskStr = taskStr + taskInstance['Instances'][0]['PrivateDnsName'] + ","
      devSakStr = devSakStr + '<entry key="https://' + taskInstance['Instances'][0]['PrivateDnsName'] + '" value="' + taskInstance['Instances'][0]['PrivateDnsName'] + ':8443/identityiq"/>\\n\\' + "\n"
  for uiInstance in uiInstances['Reservations'] :
      uiStr = uiStr + uiInstance['Instances'][0]['PrivateDnsName'] + ","
      devSakStr = devSakStr + '<entry key="https://' + uiInstance['Instances'][0]['PrivateDnsName'] + '" value="' + uiInstance['Instances'][0]['PrivateDnsName'] + ':8443/identityiq"/>\\n\\' + "\n"

  # chomp last byte
  taskStr = taskStr[:-1]
  uiStr = uiStr[:-1]

  combStr = taskStr + "\n" + uiStr + "\n"

  replaceMe = "%%TASK_HOSTS%%=global"
  devSakReplaceMe='%%DEVSAK_SERVER_MAP%%=<entry key="IP.REGION.compute.internal" value="https://IP.REGION.compute.internal:8443/identityiq"/>\\n\\'

  try:
    file = open( fileToEdit, 'r+')
  except:
    print("can't open file")
    sys.exit(1)
  
  # if we have no task hosts, then leave global as the default.

  if(len(taskInstances['Reservations'])):
   for line in fileinput.input( fileToEdit ):
     file.write ( line.replace( replaceMe, combStr ) ) 
   file.write("\n")
   file.close()

  try:
    file2 = open( fileToEdit, 'r+')
  except:
    print("can't open file")
    sys.exit(1)

  for line in fileinput.input( fileToEdit ):
    file2.write ( line.replace( devSakReplaceMe, devSakStr ) ) 
  file.close()

if __name__ == '__main__':
    main()

