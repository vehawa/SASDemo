#!/bin/bash
#content is password-management related

#handy way to create a pause for press any key to continue
#example: pause
pause()
{
    read -p "Press [Enter] to continue..."
}

#user existence check
#example from: https://superuser.com/questions/336275/find-out-if-user-name-exists
doesUserExist()
{
	if id "$1" >/dev/null 2>&1; then
		echo "true"
	else
		echo "false"
	fi
}

# turn a (possibly) relative path into a full path name.
# Useful if arguments are relative and script needs to cd.
fullpath()
{
        echo "$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
}
