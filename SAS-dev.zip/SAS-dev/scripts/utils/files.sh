#!/bin/bash
#various file and folder utilities
#helpful conditionals for if -> http://tldp.org/LDP/Bash-Beginners-Guide/html/sect_07_01.html

#delete a directory (empty or not) recursively if it exists
#$1=directory to drop
#example call: removeDirectoryIfExits /var/lib/myDir
removeDirectoryIfExits()
{
	if [ -d "$1" ]; then
		echo "directory $1 found, deleting"
		rm -rf "$1"
		echo "deleted directory $1"
	else
		echo "directory $1 not found, nothing to do"
	fi
}


#delete a file if it exists
#$1=file to drop
#example call: removeFileIfExits /root/.my.cnf
removeFileIfExits()
{
	if [ -f "$1" ]; then
		echo "file $1 found, deleting"
		rm -f "$1"
		echo "deleted file $1"
	else
		echo "file $1 not found, nothing to do"
	fi
}


#create a directory if it does not exist, creates intermediate directories
#$1=directory to make
#example call: createDirectoryIfNotExits /var/lib/myDir
createDirectoryIfNotExits()
{
	if [ ! -d "$1" ]; then
		echo "directory $1 not found, creating"
		mkdir -p "$1"
		echo "created directory $1"
	else
		echo "directory $1 was found, nothing to do"
	fi
}


#move (or rename) a single file if it exists
#$1=file to move
#$2=new path and name
#example call: moveFileIfExits /root/.my.cnf /root/dir2/.my.cnf.2
moveFileIfExits()
{
	if [ -f "$1" ]; then
		echo "file $1 found, moving to $2"
		mv -v "$1" "$2"
		echo "moved file $1 to $2"
	else
		echo "file $1 not found, nothing to do"
	fi
}