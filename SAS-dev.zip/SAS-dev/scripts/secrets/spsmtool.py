#!/usr/bin/env python

'''
SailPoint Secrets Manager Tool (spsmtool) for IIQ CMS cloud deployments.

This tool allows programs and developers to manipulate the secrets store
for an IIQ CMS customer environment.  Currently it relies on AWS SM as
the back-end, but this could be expanded/changed in the future.


required inputs:
    --customer or $CUSTOMER
    --env[ironment] or $ENV
    --region or $AWS_DEFAULT_REGION (when using AWS backend)
operation modes:
    - export: run command with secrets exported to environment variables
    - list: show all available secret environment variable names
    - set: create new secret or modify secret attributes/value
    - init: create initial secrets (not implemented)
    - review: show where secrets are not following conventions
optional inputs:
    --scope: scope to limit list/export to
    --role: AWS role to assume or use $AWS_CUSTOMER_ROLE
    --profile: credentials profile
    backend specifier (not implemented)
    --product: name of product (defaults to iiqcms)

TODO:
    - support @SECRETS as command argument (like summon)
    - implement other operational modes besides export
        --init
    - prune secrets by tags
    - fix where secret filter options can cause excess review check failures

'''

import os
import sys
import argparse
import boto3
import base64
from botocore.exceptions import ClientError
import json
from datetime import date, datetime
import re
import tempfile
import subprocess
import abc
from dotenv import load_dotenv

def parse_args():
    """ Parse command line args, return args object. """
    parser = argparse.ArgumentParser(description="SailPoint Secrets Manager Tool")
    parser.add_argument('--customer', '-c', action='store',
                        default=os.getenv('CUSTOMER'),
                        help='Name of customer')
    parser.add_argument('--environment', '-e', action='store',
                        dest='env', default=os.getenv('ENV'),
                        help='Name of environment for customer')
    parser.add_argument('--product', '-P', action='store',
                        default="iiqcms",
                        help='Product name (default="iiqcms")')
    parser.add_argument('--role', action='store',
                        default=os.getenv('AWS_CUSTOMER_ROLE'),
                        help='AWS IAM role to assume')
    parser.add_argument('--profile', '-p', action='store',
                        help='AWS credentials profile to use')
    parser.add_argument('--region', '-r', action='store',
                        help='AWS region for customer environment')
    parser.add_argument('--scope', '-s', action='store',
                        help='Speciy scope for secret')
    parser.add_argument('--type', '-t', action='store',
                        help='Speciy type of secret')
    parser.add_argument('--tag', '-T', action='append',
                        dest='tags',
                        help='Speciy tags for secret')
    parser.add_argument('--file', '-f', action='store_true',
                        help='Interpret secret value as a file name')
    parser.add_argument('--var', '-v', action='store',
                        help='Specify environment variable name')

    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument('--export', '-x', action='store_const',
                            dest='mode', const="export",
                            help='export secrets as environment variables')
    mode_group.add_argument('--list', '-l', action='store_const',
                            dest='mode', const="list",
                            help='list available secret names')
    mode_group.add_argument('--set', '-S', action='store_const',
                            dest='mode', const="set",
                            help='create or modify a secret')
    mode_group.add_argument('--init', '-i', action='store_const',
                            dest='mode', const="init",
                            help='generate and store initial iiq secrets')
    mode_group.add_argument('--review', '-R', action='store_const',
                            dest='mode', const="review",
                            help='review secrets and report issues')

    # get the rest as list of args.
    parser.add_argument('cmd', action='store', nargs=argparse.REMAINDER)

    args = parser.parse_args()
    if args.mode is None:
        args.mode = 'export'
    if args.mode == 'export' and len(args.cmd) == 0:
        parser.error("A command is required with export mode")
    if args.mode == 'set':
        if len(args.cmd) < 1:
            parser.error("Set mode must have a secret name")
        if len(args.cmd) > 2:
            parser.error("Too many arguments for set mode")
    if args.file and args.mode != 'set':
        parser.error("The file option is only valid with set mode")

    return args


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError ("Type %s not serializable" % type(obj))


# product, customer, env, scope, name, type.
class CMSSecret(object):
    """ Class that hold secrets, with attributes. """
    def parse_fullname(self):
        parts = self.fullname.split('/')
        if len(parts) == 4:
            rv = (parts[0], parts[1], parts[2])
            name = parts[3]
        else:
            rv = (None, None, None)
            name = self.fullname
        subparts = name.split('.')
        if len(subparts) >= 3:
            rv += (subparts[0], '.'.join(subparts[1:-1]), subparts[-1])
        else:
            rv += (None, name, None)
        return rv

    def _parse_name(self):
        pieces = self.parse_fullname()
        if all(pieces[0:3]):
            self.product = pieces[0].lower()
            self.customer = pieces[1].lower()
            self.env = pieces[2].lower()
        if all(pieces[3:6]):
            self.scope = pieces[3].lower()
            self.name = pieces[4].lower()
            self.type = pieces[5].lower()
            self.var = '_'.join(["SECRET", self.scope, self.name, self.type])
        else:
            self.name = pieces[4]
            self.var = "SECRET_" + self.name
        self.name = re.sub('[^\w]', '.', self.name)
        self.var = re.sub('[^\w]', '_', self.var).upper()

    def use_tags(self, tags):
        if isinstance(tags, list):
            mytags = {}
            for t in tags:
                if 'Value' in t:
                    mytags[t['Key'].lower()] = t['Value'].lower()
                else:
                    mytags[t['Key'].lower()] = None
        else:
            mytags = dict((k.lower, v.lower) for k,v in tags.items())
        self._tags = dict(mytags)

        if 'product' in mytags:
            self.product = mytags['product']
            del mytags['product']
        if 'customer' in mytags:
            self.customer = mytags['customer']
            del mytags['customer']
        if 'environment' in mytags:
            self.env = mytags['environment']
            del mytags['environment']
        if 'scope' in mytags:
            self.scope = mytags['scope']
            del mytags['scope']
        if 'type' in mytags:
            self.type = mytags['type']
            del mytags['type']
        if 'var' in mytags:
            self.var = re.sub('[^\w]', '_', mytags['var']).upper()
            del mytags['var']
        self.extra_tags = mytags

    def __init__(self, name, tags={}, customer=None, env=None, product="iiqcms"):
        self.product = product
        self.customer = customer
        self.env = env
        self.scope = "app"
        self.name = name
        self.fullname = name
        self.type = "password"
        self.extra_tags = {}
        self._tags = {}
        self._parse_name()
        self.use_tags(tags)
        self.secret = None
        self.tmpfile = None

    @property
    def value(self):
        if self.type in ['file', 'keyfile']:
            return self.tmpfile.name
        else:
            return self.secret

    @value.setter
    def value(self, value):
        self.secret = value
        if self.tmpfile is not None:
            tmpfile.close()
        if self.type in ['file', 'keyfile']:
            self.tmpfile = tempfile.NamedTemporaryFile()
            if not isinstance(self.secret, bytes):
                self.tmpfile.write(self.secret.encode())
            else:
                self.tmpfile.write(self.secret)
            self.tmpfile.flush()

def list_secret_names(secrets):
    for s in secrets:
        print(s.var)

def export_to_command(secrets, cmdline):
    """ run command with secrets in environment variables """
    exports = os.environ.copy()
    for s in secrets:
        exports[s.var] = s.value
    rv = subprocess.call(cmdline, shell=True, env=exports)
    sys.exit(rv)

# fullmatch is a python 3.4 function.
# https://stackoverflow.com/a/30212414
def _fullmatch(regex, string, flags=0):
    """Emulate python-3.4 re.fullmatch()."""
    return re.match("(?:" + regex + r")\Z", string, flags=flags)

def set_secret(SM, args):
    """ create or set a secret with value and tags """
    name = re.sub('[^\w]', '.', args.cmd[0]).lower()
    tags = {}
    if args.tags:
        for t in args.tags:
            tp = t.split('=', maxsplit=1)
            if len(tp) == 1:
                tv = None
            else:
                tv = t[1]
            tags[tp[0].lower()] = tv.lower()

    new_secret = CMSSecret(name, tags, customer=args.customer, env=args.env, product=args.product)
    if args.var:
        new_secret.var = args.var
    else:
        new_secret.var = None
    if args.type:
        new_secret.type = args.type.lower()
    if args.scope:
        new_secret.scope = args.scope.lower()
    if len(args.cmd) == 2:
        ref = args.cmd[1]
        if args.file:
            with open(ref, 'rb') as secret_file:
                content = secret_file.read()
            tf = bytearray({7,8,9,10,12,13,27} | set(range(0x20, 0x100)) - {0x7f})
            is_binary = lambda bytes: bool(bytes.translate(None, tf))
            if is_binary(content):
                new_secret.secret = content
            else:
                new_secret.secret = content.decode()
        else:
            new_secret.secret = os.environ[ref]
    else:
        new_secret.secret = None
    # mangle fullname for various use cases. Not all cases are covered.
    if not _fullmatch(r'[\w]+/[\w]+/[\w]+/[\w]+\.[\w.]+\.[\w]+' , new_secret.fullname):
        if _fullmatch(r'[\w]+\.[\w.]+\.[\w]+', new_secret.fullname):
            new_secret.fullname = '/'.join([new_secret.product, new_secret.customer, new_secret.env, new_secret.fullname])
        else:
            new_secret.fullname = '/'.join([new_secret.product, new_secret.customer, new_secret.env, '.'.join([new_secret.scope, new_secret.name, new_secret.type])])
    new_secret.fullname = new_secret.fullname.lower()
    SM.set(new_secret)


def review_secrets(secrets):
    """ review list of secrets and point out issues """
    """ checks performed:
        - are all the secrets we need present? (by env var name)
        - are there any duplicate secrets (by env var name)
        - do all the expected tags exist for each secret?
        - are there secrets with unexpected scope, type?
        - is the secret env var in the expected format?
        - is the name in the expected format?
        - do the tags match the name?
        - is secret missing customer, env, or product?
    """
    errcnt = 0
    warncnt = 0
    # make sure we have all the secrets we were expecting.
    secret_vars = [s.var for s in secrets]
    expected_secrets = [
        "SECRET_CLOUD_BASTION_USER",
        "SECRET_CLOUD_BASTION_KEY_FILE",
        "SECRET_CLOUD_HOST_USER",
        "SECRET_CLOUD_HOST_KEY_FILE",
        "SECRET_CLOUD_DB_USER",
        "SECRET_CLOUD_DB_PASSWORD",
        "SECRET_CLOUD_DATADOG_KEY",
        "SECRET_CLOUD_THREATSTACK_KEY",
        "SECRET_IIQ_ADMIN_USER",
        "SECRET_IIQ_ADMIN_PASSWORD",
        "SECRET_IIQ_CFG_FILE",
        "SECRET_IIQ_DAT_FILE",
        "SECRET_IIQ_DB_PASSWORD",
        "SECRET_IIQ_DB_USER",
        "SECRET_IIQ_PLUGINDB_PASSWORD",
        "SECRET_IIQ_PLUGINDB_USER",
        "SECRET_IIQ_TOMCAT_PASSWORD",
        "SECRET_IIQ_TOMCAT_USER",
        "SECRET_IIQ_TOMCATJMX_USER",
        "SECRET_IIQ_TOMCATJMX_PASSWORD",
        "SECRET_IIQ_DATADOGSQL_USER",
        "SECRET_IIQ_DATADOGSQL_PASSWORD"
    ]
    for s in secret_vars:
        if s in expected_secrets:
            expected_secrets.remove(s)
    for s in expected_secrets:
        print("Missing expected secret " + s)
        errcnt += 1
    # detect duplicates. Not efficient, but works.
    seen = {}
    for n, s in enumerate(secrets):
        if s.var in seen:
            continue
        dups = []
        for ss in secrets[:n]:
            if s.var == ss.var:
                dups.append(ss.fullname)
        if len(dups) > 0:
            errcnt += len(dups)
            dups.append(s.fullname)
            print("duplicate secrets for " + s.var + " -> " + dups)
            seen[s.var] = 1
    # find missing tags
    expected_tags = ["product", "customer", "environment", "scope", "type"]
    for s in secrets:
        for t in expected_tags:
            if t not in s._tags:
                print("secret {} missing tag {}".format(s.fullname, t))
                errcnt += 1
    # check scope and type
    for s in secrets:
        if s.scope not in ["cloud", "iiq", "app"]:
            print("unknown scope {} for secret {}".format(s.scope, s.fullname))
            warncnt += 1
        if s.type not in ["user", "password", "file"]:
            print("unknown type {} for secret {}".format(s.type, s.fullname))
            warncnt += 1
    # see if the secret env var is in standard format
    for s in secrets:
        if not _fullmatch(r'SECRET_[\w]+_[\w_]+_[\w]+' , s.var):
            print("nonstandard env var name {} for secret {}".format(s.var, s.fullname))
            warncnt += 1
    # is name in standard format?
    for s in secrets:
        if not _fullmatch(r'[\w]+/[\w]+/[\w]+/[\w]+\.[\w.]+\.[\w]+', s.fullname):
            print("nonstandard secret name {}".format(s.fullname))
            errcnt += 1
    # does the name match the tags?
    for s in secrets:
        parts = s.parse_fullname()
        if parts[0].lower() != s._tags.get('product'):
            print("secret name {} does not match product tag {}".format(s.fullname, s._tags.get('product')))
            errcnt += 1
        if parts[1].lower() != s._tags.get('customer'):
            print("secret name {} does not match customer tag {}".format(s.fullname, s._tags.get('customer')))
            errcnt += 1
        if parts[2].lower() != s._tags.get('environment'):
            print("secret name {} does not match env tag {}".format(s.fullname, s._tags.get('environment')))
            errcnt += 1
        if parts[3].lower() != s._tags.get('scope'):
            print("secret name {} does not match scope tag {}".format(s.fullname, s._tags.get('scope')))
            errcnt += 1
        if parts[5].lower() != s._tags.get('type'):
            print("secret name {} does not match type tag {}".format(s.fullname, s._tags.get('type')))
            errcnt += 1
        # also see if customer, product env are explicit.
        if parts[0] is None and s._tags.get('product') is None:
            print("secret {} has no explicit product".format(s.fullname))
            errcnt += 1
        if parts[1] is None and s._tags.get('customer') is None:
            print("secret {} has no explicit customer".format(s.fullname))
            errcnt += 1
        if parts[2] is None and s._tags.get('environment') is None:
            print("secret {} has no explicit environment".format(s.fullname))
            errcnt += 1
    return (errcnt, warncnt)


# https://stackoverflow.com/a/41622155
if sys.version_info >= (3, 4):
    ABC = abc.ABC
else:
    ABC = abc.ABCMeta('ABC', (), {})


'''
secretsmanager class
must implement:
    __init__
    list
    get (secret value)
    set (secret value, tags, also creates secret)
'''

class AbstractSecretsManager(ABC):
    """ Abstract class for SecretsManager. """

    @abc.abstractmethod
    def __init__(self, client_args):
        """ args is a **dict list of client arguments """
        self.client_args = client_args
        super(AbstractSecretsManager, self).__init__()

    @abc.abstractmethod
    def list(self, args):
        """ list all secret names, with metadata, from client. """
        pass

    @abc.abstractmethod
    def get(self, secret):
        """ get the secret value """
        pass

    @abc.abstractmethod
    def set(self, secret):
        """ create secrets, set value, change tags """
        pass

class AWSSecretsManager(AbstractSecretsManager):
    """ Implementation of SecretsManager for AWS SM resource """
    def __init__(self, client_args):
        super(AWSSecretsManager, self).__init__(client_args)
        if 'role' in client_args:
            self._assume_role()
        self._client = boto3.client('secretsmanager', **self.client_args)

    def _assume_role(self):
        """ assume role, fix up client_args """
        role = self.client_args['role']
        del self.client_args['role']

        sts_client = boto3.client('sts', **self.client_args)
        aro = sts_client.assume_role(RoleArn=role, RoleSessionName="SMCustomerRole")
        creds = aro['Credentials']

        self.client_args['aws_access_key_id'] = creds['AccessKeyId']
        os.environ["AWS_ACCESS_KEY_ID"] =  creds['AccessKeyId']
        self.client_args['aws_secret_access_key'] = creds['SecretAccessKey']
        os.environ["AWS_SECRET_ACCESS_KEY"] =  creds['SecretAccessKey']
        self.client_args['aws_session_token'] = creds['SessionToken']
	os.environ["AWS_SESSION_TOKEN"] =  creds['SessionToken']
        os.environ.pop("AWS_CUSTOMER_ROLE", None)

    def list(self, args):
        """ must return a list of CMSSecrets """
        secrets_list = []
        resp = self._client.list_secrets()
        secrets_list = resp['SecretList']
        while 'NextToken' in resp:
            resp = self._client.list_secrets(NextToken=resp['NextToken'])
            secrets_list.extend(resp['SecretList'])

        cms_secrets = []
        for s in secrets_list:
            cs = CMSSecret(s['Name'], s['Tags'], customer=args.customer, env=args.env, product=args.product)
            # prune secrets that do not match the criteria
            if args.scope and args.scope.lower() != cs.scope.lower():
                continue
            if args.product.lower() != cs.product.lower():
                continue
            if cs.customer.lower() != args.customer.lower() or cs.env.lower() != args.env.lower():
                continue
            if args.var and args.var != cs.var:
                continue
            if args.type and args.type.lower() != cs.type.lower():
                continue
            # match based on tags? later
    
            cms_secrets.append(cs)
        return cms_secrets

    def get(self, secret):
        """ get the value of a secret """
        try:
            resp = self._client.get_secret_value(SecretId=secret.fullname)
        except ClientError as e:
            return None
        else:
            if 'SecretString' in resp:
                value = resp['SecretString']
            else:
# docs say binary is base64 encoded, but it apparently isn't.
#                value = base64.b64decode(resp['SecretBinary'])
                 value = resp['SecretBinary']
        return value

    def _is_binary_secret(self, value):
        """ detect (in version agnostic way) if secret value is binary. """
        if isinstance(value, bytes) and isinstance(value, str):
            # python2 where a str is bytes. Use macro test.
            tf = bytearray({7,8,9,10,12,13,27} | set(range(0x20, 0x100)) - {0x7f})
            is_binary = lambda bytes: bool(bytes.translate(None, tf))
            return is_binary(value)
        else:
            # python3: just test the type
            return isinstance(value, bytes)


    def set(self, secret):
        """ set/create secrets with tags and optional value """
        # setup tags
        smtags = []
        if secret.extra_tags:
            for et in secret.extra_tags:
                smtags.append({'Key': et, 'Value': secret.extra_tags[et]})
        smtags += [
            { 'Key': 'product', 'Value': secret.product },
            { 'Key': 'customer', 'Value': secret.customer },
            { 'Key': 'environment', 'Value': secret.env },
            { 'Key': 'scope', 'Value': secret.scope },
            { 'Key': 'type', 'Value': secret.type }
        ]
        if secret.var is not None:
            smtags.append({'Key': 'var', 'Value': secret.var})

        # see if secret exists.
        try:
            self._client.describe_secret(SecretId=secret.fullname)
        except ClientError as e:
            if secret.secret is None:
                raise ValueError("Secret does not exist and no value specified. Cannot create an empty secret.")
            if self._is_binary_secret(secret.secret):
                self._client.create_secret(Name=secret.fullname, Tags=smtags, SecretBinary=secret.secret)
            else:
                self._client.create_secret(Name=secret.fullname, Tags=smtags, SecretString=secret.secret)
        else:
            # it exists. fix the tags first, then the value (if needed)
            self._client.tag_resource(SecretId=secret.fullname, Tags=smtags)
            if secret.secret is not None:
                if self._is_binary_secret(secret.secret):
                    self._client.put_secret_value(SecretId=secret.fullname, SecretBinary=secret.secret)
                else:
                    self._client.put_secret_value(SecretId=secret.fullname, SecretString=secret.secret)


# main Main MAIN
def main():

    # lets get the environment variables for this target
    load_dotenv(dotenv_path='target.env')

    args = parse_args()

    client_args = {}
    if args.profile:
        client_args['profile_name'] = args.profile
    if args.region:
        client_args['region_name'] = args.region
    if args.role:
        client_args['role'] = args.role

    if args.customer is None:
        raise ValueError("customer name not found. Use --customer or set $CUSTOMER")
    if args.env is None:
        raise ValueError("environment name not found. Use --env or set $ENV")

    SM = AWSSecretsManager(client_args)

    if args.mode in ['list', 'export', 'review']:
        cms_secrets = SM.list(args)

    if args.mode == 'list':
        list_secret_names(cms_secrets)
    elif args.mode == 'export':
        for cs in cms_secrets:
            cs.value = SM.get(cs)
        cmdline = ' '.join(args.cmd)
        export_to_command(cms_secrets, cmdline)
        # NOTREACHED: export_to_command should not return
    elif args.mode == 'set':
        set_secret(SM, args)
    elif args.mode == 'review':
        (errs, warns) = review_secrets(cms_secrets)
        if (errs > 0):
            sys.exit(errs)
    else:
        raise ValueError("Unimplemented mode " + args.mode)


if __name__ == '__main__':
    main()

