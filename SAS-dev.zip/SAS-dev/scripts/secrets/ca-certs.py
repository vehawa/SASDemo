#!/usr/bin/python

# Print out the names of the 

import os

for envVar in os.environ:
    if "SECRET_IIQ_SSL_CA_" in envVar:
        print(envVar)