# IIQ CMS Secrets conventions

IIQ CMS build pipeline relies on a number of secrets in order to configure a customer environment, set up IIQ and deploy it to a cloud environment.  While trying to remain flexible, having a common naming and tagging convention for secrets makes things easier and smoother.

## Secret attributes

All secrets are classified by:
  - product name, which should always be "iiqcms".  Future development may need other product names.
  - customer name, which must be unique.
  - environment name, which must be unique within a customer.
  - scope, which defines some access characteristic for a secret. Current scopes are "cloud", "iiq", and "app".  Other scopes may be added in the future.
  - name, a short identifier for a secret. Secret names should not conflict.
  - type, which helps determine how a secret is handled.  Current types are: "user", "password", "file".  Other types may be added as needed.
 
Attribute names should be single words consisting of alpha-numeric characters and underscore ('_') without punctuation or spaces. Any special characters or spaces will be force-converted to a "safe" character, usually '.' or '_', depending on the context.  Attributes should not be distinguished solely on case as there are contexts where the attributes will not be case sensitive.  IE: "ACME" and "acme" should not represent two different customers.  The short name may contain separators ('.') so that eg "monkey.barrels" is a valid short name.

## Full secret name
The "full" secret name that is used to store it in a secrets store is formed from its attributes.  The pattern is: ${product}/${customer}/${env}/${scope}.${name}.${type}.
Example: "iiqcms/customerA/test/cloud.bastion.file".

## Secret tags
When stored in a secret store, secrets are tagged with their attributes. The tags should be:
  - product
  - customer
  - Environment
  - scope
  - type
Optionally the tag "var" can be used to explicitly set the mapping from a secret to an environment variable.  Other, extra, tags can be added but will be ignored.  Future behaviors may require added tags.

## Secrets as environment variables
Secrets are exported from the secrets store as environment variables, which can then be accessed by build tools without having the content exposed on a command line where it is visible to other users.

Secret environment variable names are always in ALL CAPS, with any non alpha-numeric character converted to '_'.  Every secret name begins with "SECRET", and include the scope, name and type of the secret separated by unerscores.  Example: "SECRET_IIQ_CFG_FILE".

The default secret environment variable name may be over-ridden if the secret has a 'var' tag that explicitly maps the secret to an environment variable name.

### file secrets

Secrets of type 'file' do not have thier contents as the value of the environment variable.  Instead, the value contains a file name which has the contents of the secret in it.  These files are temporary, only accessible by the current user and are automatically removed when the program exits.  So to get the actual value of the secret cloud.bastion.file, you would get the file name from $SECRET_CLOUD_BASTION_FILE and read the PEM key from that file.

## Attribute derivation, default and precedence.

Normally, the secret attributes can be derived from either the secret name or tags, which should both agree.  In the case where there is a conflict, the secret tags will take precedence.  In the case where there are missing tags, the attribute will be parsed from the full secret name.  If the secret full name is not in the conventional format, then default attribute values will be used, if possible.  Some heuristics will be used to derive attributes from partial secret names.

Defaults for attributes are:
  - product: "iiqcms"
  - customer: $CUSTOMER or customer name from command line.
  - env: $ENV or environment name from command line
  - scope: "app"
  - name: full name of secret
  - type: "password"

It is vastly preferred that the secret attributes, full name and tags all agree by conforming to the conventions.

Some attributes, if completly missing, will be considered to be wildcards.  This is only allowed so that secrets which are accidentally mis-tagged AND named will not be lost. The attributes that are wildcarded are: 'product', 'customer' and 'env'.

# Creating and managing secrets

## cloud secrets
Cloud secrets are part of the cloud configuration and will be provided by the cloud provider, Rackspace, or generated on site as part of an ad-hoc development sandbox.  They must be entered manually, either using the AWS console, or with the secrets manager tool.
Normally access to these secrets is read-only to the build server. For cloud based environments only the build server should be able to access them.  They are never shared with customers in test or production environments.

## iiq secrets
Secrets in iiq scope are used to configure IIQ itself.  An example would be the password for the IIQ Administrator account.  These secrets are generated by IIQ CMS and are not shared with customers.  The build server should have read and write access to these secrets.

### creating initial iiq secrets (creds.sh)
The iiq secrets can be initially generated using the "scipts/secrets/creds.sh" script  in the pipeline repository.  It must be run from the environment directory after the initial download and unpacking of the IIQ media.  The $CUSTOMER and $ENV environment variables must be defined.  Default usernames will be used unless the corresponding environment variables are set.
  - SPADMIN_USER
  - IIQDB_USER
  - IIQPLUGINDB_USER
  - TOMCAT_USER

Complex, random passwords will be generated as needed.  The script will also create a new IIQ keystore (iiq.dat and iiq.cfg file), and store them in the secret store.

For an,  SECRET_IIQ_ADMIN_PASSWORD, SECRET_IIQ_DB_PASSWORD and SECRET_IIQ_PLUGINDB_PASSWORD secrets will have iiq encrypted version with the _KEYSTORE suffix.  So ${env.SECRET_IIQ_ADMIN_PASSWORD_KEYSTORE} will contain the iiq encrypted version of the secret, which can be placed in XML files for IIQ to import.

## app secrets
Application scope secrets are provided by the customer to access thier on-prem or SaaS applications via IIQ connectors.  These secrets are entered by the customer via the AWS SecretsManager console.  [We may provide a command or website for the customer to do this in a later release.]  The build pipeline has read-only access to these secrets.  SS and DevOps should never have access to these secrets.

Application secrets can be used as substitution tokens in the IIQ config XML files.  Ant will also use the iiq encrypt command to provide encrypted versions of the app secrets and export them in the same way as the app secrets with the _KEYSTORE suffix.   For example, the secret that ant sees as ${env.APP_FOO_PASSWORD} will have an iiq encrypted version in ${env.APP_FOO_PASSWORD_KEYSTORE}.  These secrets can then be substituted into XML files that IIQ will import.

# Secrets Manager tool
A tool has been created to help manage secrets for CMS.  The tool is found at "scripts/secrets/spsmtool.py".  Normal mode of operation if for the tool to use the configured AWS credentials to access AWS Secrets Manager and get the secrets for a particular customer environment.  Those secrets are then exported to a command as environment variables..  Secrets can be filtered by attributes.  The secrets tool will automatically handle the different secret types, including 'file' types.
Other modes of operation include listing the secret environment variable names available and creating new secrets or changing existing secrets values and attributes.  The spsmtool.py usage and help will provide more details.  For most purposes, the tool will only be used by the creds.sh script and the build pipeline.  It should only be used directly when configuring dev or adhoc environments, never for actual cloud environments.

