#!/bin/bash
# shell script to generate initial cloud creds with values 
# to be set by CMS DevOps


# configuration: these env vars must be set or placed in target.env
# $CUSTOMER
# $ENV
# You must also have AWS credentials for the customer AWS account.
# THIS MUST INCLUDE setting the region, usually with $AWS_DEFAULT_REGION


# main Main MAIN

# import target env vars
set -a
. target.env
set +a

# exit if we fail anywhere.
set -e 

# make sure we have customer and environment
if [ -z "$CUSTOMER" ]
then
	echo "Missing customer name in \$CUSTOMER"
	exit 1
fi
if [ -z "$ENV" ]
then
	echo "Missing environment in \$ENV"
	exit 1
fi

# some defaults.
SMTOOL="../../scripts/secrets/spsmtool.py"

# Announce the ARN this is executing under and confirm
echo "****************************************************************"
echo "Cloud Secret Loader - Loads the Initial Cloud Secrets"
echo "This tool will not over-write existing cloud secrets"
echo "I am operating on customer $CUSTOMER and environment $ENV"
echo "Please confirm the ARN you wish to use is displayed below"
aws sts get-caller-identity | grep Arn
echo "****************************************************************"
read -n 1 -s -r -p "Press any key to continue, ctrl+c to terminate:"

echo -ne "\n\n\n"

echo "****************************************************************"
echo "Starting the cloud secret process..."
echo "****************************************************************"

echo -ne "\n\n"

# get list of existing secrets, if any.
OLD_SECRETS=""
OLD_SECRETS=$($SMTOOL --list)

# store user/passwords: will not overwrite existing secrets
if echo $OLD_SECRETS | grep -wq "SECRET_CLOUD_BASTION_USER"
then
	echo "cloud.bastion.user already exists"
else
	echo -n "Enter cloud.bastion.user: "
	read CLBSTUSR
	echo "Pushing cloud.bastion.user"
	KEY=$CLBSTUSR $SMTOOL --scope cloud --set cloud.bastion.user KEY
fi

if echo $OLD_SECRETS | grep -wq "SECRET_CLOUD_BASTION_KEY_FILE"
then
	echo "cloud.bastion.key.file already exists"
else
	echo -n "Enter cloud.bastion.key.file path: "
	read CLBSTKEY
	echo "Pushing cloud.bastion.key.file"
	KEY=$CLBSTKEY $SMTOOL --scope cloud --file --set cloud.bastion.key.file $CLBSTKEY
fi

if echo $OLD_SECRETS | grep -wq "SECRET_CLOUD_HOST_USER"
then
	echo "cloud.host.user already exists"
else
	echo -n "Enter cloud.host.user: "
	read CLHOSTUSR
	echo "Pushing cloud.host.user"
	KEY=$CLHOSTUSR $SMTOOL --scope cloud --set cloud.host.user KEY
fi

if echo $OLD_SECRETS | grep -wq "SECRET_CLOUD_HOST_KEY_FILE"
then
	echo "cloud.host.key.file  already exists"
	
else
	echo -n "Enter cloud.host.key.file path: "
	read CLHOSTKEY
	echo "Pushing cloud.host.key.file "	
	KEY=$CLHOSTKEY $SMTOOL --scope cloud --set --file cloud.host.key.file $CLBSTKEY
fi

if echo $OLD_SECRETS | grep -wq "SECRET_CLOUD_DB_USER"
then
	echo "cloud.db.user already exists"
else
	echo -n "Enter cloud.db.user: "
	read CLDBUSR
	echo "Pushing cloud.db.user"
	KEY=$CLDBUSR $SMTOOL --scope cloud --set cloud.db.user KEY
fi

if echo $OLD_SECRETS | grep -wq "SECRET_CLOUD_DB_PASSWORD"
then
	echo "cloud.db.password already exists"
else
	echo -n "Enter cloud.db.password: "
	read -s CLDBPWD
	echo -en "\nReenter cloud.db.password: "
	read -s CLDBPWD2
	if [[ "$CLDBPWD" != "$CLDBPWD2"  ]]; then
	  echo "ERROR: DB Passwords do not match!"
	  exit 1
	fi
	echo "Pushing cloud.db.password"
	KEY=$CLDBPWD $SMTOOL --scope cloud --set cloud.db.password KEY
fi

if echo $OLD_SECRETS | grep -wq "SECRET_CLOUD_DATADOG_KEY"
then
	echo "cloud.datadog.key already exists"
else
	echo -n "Enter cloud.datadog.key: "
	read CLDDG
	echo "Pushing cloud.datadog.key"
	KEY=$CLDDG $SMTOOL --scope cloud --set cloud.datadog.key KEY
fi

if echo $OLD_SECRETS | grep -wq "SECRET_CLOUD_THREATSTACK_KEY"
then
	echo "cloud.threatstack.key already exists"
else
	echo -n "Enter cloud.threatstack.key: "
	read CLTSK
	echo "Pushing cloud.threatstack.key"
	KEY=$CLTSK $SMTOOL --scope cloud --set cloud.threatstack.key KEY
fi
