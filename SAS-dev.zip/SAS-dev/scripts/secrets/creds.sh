#!/bin/bash
# shell script to generate initial iiq credentials and store them
# in secret storage using the spsmtool

# if the cfg/dat files exist, back them up
# if the cfg/dat secrets exist, fetch them
# else create them, store them
# for @ secret,
#  make random password
#  store in secretsmanager

# configuration: these env vars must be set or placed in target.env
# $CUSTOMER
# $ENV
# You must also have AWS credentials for the customer AWS account.
# THIS MUST INCLUDE setting the region, usually with $AWS_DEFAULT_REGION


#handy way to generate a password of varying length using /dev/urandom
#taken from: https://unix.stackexchange.com/questions/230673/how-to-generate-a-random-string
#$1=length of new password, defaults to 10
#example call: myPass=$(getNewPassword 10) -> then you could use $myPass to use new password of length 10
getNewPassword()
{
    local result=$(head /dev/urandom | env LC_CTYPE=C tr -dc A-Za-z0-9 | head -c${1-10})
    echo $result
}


#handy way to generate a password of varying length using /dev/urandom
#taken from: https://unix.stackexchange.com/questions/230673/how-to-generate-a-random-string
#this includes owasp special char list, minus a couple troublesome things like double quote: https://www.owasp.org/index.php/Password_special_characters
#$1=length of new password, defaults to 14
#example call: myPass=$(getNewPassword 16) -> then you could use $myPass to use new password of length 16
getNewComplexPassword()
{
	#default to something divisble evenly by 4
	local totalLength=${1-16}

	#upper, lower, digit, special
	local partCount=4

	#assign counts and figure remainder, if any
	local remainder=$(( totalLength % partCount ))
	local upperCount=$(( totalLength / partCount ))
	local lowerCount=$(( totalLength / partCount ))
	local digitCount=$(( totalLength / partCount ))

	if [ $remainder == 0 ]; then
		local specialCount=$(( totalLength / partCount ))
	else
		local specialCount=$remainder
	fi

	#get each piece
	local result=$(head /dev/urandom | env LC_CTYPE=C tr -dc 'A-Z' | head -c$upperCount)
	result+=$(head /dev/urandom | env LC_CTYPE=C tr -dc 'a-z' | head -c$lowerCount)
	result+=$(head /dev/urandom | env LC_CTYPE=C tr -dc '0-9' | head -c$digitCount)
	result+=$(head /dev/urandom | env LC_CTYPE=C tr -dc '!#$%&*+,-.:;<=>?@[]^_{|}' | head -c$specialCount)
    
	#scramble a the result so it's less predictable
    scrambleString $result
}


# randomly re-arrange the characters in a string
#$1: string to scramble
#https://stackoverflow.com/questions/26326286/bash-scramble-characters-contained-in-a-string
#example: scrambled=$(scrambleString abc123)
scrambleString() {
    local a=$1 i
    local scrambled=
			while((${#a})); do
				((i=RANDOM%${#a}))
				scrambled+=${a:i:1}
				a=${a::i}${a:i+1}
			done
	echo $scrambled
}

# main Main MAIN

# import target env vars
set -a
. target.env
set +a

# make sure we have customer and environment
if [ -z "$CUSTOMER" ]
then
	echo "Missing customer name in \$CUSTOMER"
	exit 1
fi
if [ -z "$ENV" ]
then
	echo "Missing environment in \$ENV"
	exit 1
fi

# some defaults.
SMTOOL="../../scripts/secrets/spsmtool.py"
WIDIR="../../build/extract/WEB-INF"
KSDIR="$WIDIR/classes"
IIQCMD="$WIDIR/bin/iiq"

# first make backups of existing files (just in case)
if [ -f $KSDIR/iiq.cfg ]
then
	echo "backing up $KSDIR/iiq.cfg to $KSDIR/iiq.cfg.bak"
	mv $KSDIR/iiq.cfg $KSDIR/iiq.cfg.bak
fi
if [ -f $KSDIR/iiq.dat ]
then
	echo "backing up $KSDIR/iiq.dat to $KSDIR/iiq.dat.bak"
	mv $KSDIR/iiq.dat $KSDIR/iiq.dat.bak
fi


# get list of existing secrets, if any.
OLD_SECRETS=""
OLD_SECRETS=$($SMTOOL --list)


# see if there is already a keystore file set
NEW_IIQCFG="No"
if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_CFG_FILE"
then
	echo "retrieving existing iiq.cfg"
	$SMTOOL cp \$SECRET_IIQ_CFG_FILE $KSDIR/iiq.cfg
else
	NEW_IIQCFG="Yes"
fi
NEW_IIQDAT="No"
if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_DAT_FILE"
then
	echo "retrieving existing iiq.dat"
	$SMTOOL cp \$SECRET_IIQ_DAT_FILE $KSDIR/iiq.dat
else
	NEW_IIQDAT="Yes"
fi

if [ "$NEW_IIQDAT" != "$NEW_IIQCFG" ]
then
	echo "ERROR: keystore files were not synced. Exiting."
	exit 2
fi

if [ "$NEW_IIQDAT" == "Yes" ]
then
	chmod +x $IIQCMD
	# create iiq.cfg with new master key
	echo "creating new master key in $KSDIR/iiq.cfg"
	echo "master
y" | $IIQCMD keystore &>/dev/null
	# and update the keystore itself
	echo "creating new keystore in $KSDIR/iiq.dat"
	echo "addKey
y" | $IIQCMD keystore &>/dev/null
	# store cfg
	echo "Storing $KSDIR/iiq.cfg as iiq.cfg.file"
        $SMTOOL --set --file iiq.cfg.file $KSDIR/iiq.cfg
	# store dat
	echo "Storing $KSDIR/iiq.dat as iiq.dat.file (binary)"
        $SMTOOL --set --file iiq.dat.file $KSDIR/iiq.dat
fi

# now generate some passwords and usernames
SPADMIN_USER=${SPADMIN_USER-spadmin}
SPADMIN_PASSWORD=$(getNewComplexPassword 24)
IIQDB_USER=${IIQDB_USER-iiq}
IIQDB_PASSWORD=$(getNewComplexPassword 24)
IIQPLUGINDB_USER=${IIQPLUGINDB_USER-iiqplugin}
IIQPLUGINDB_PASSWORD=$(getNewComplexPassword 24)
TOMCAT_USER=${TOMCAT_USER:-tomcat}
#The tomcat password goes into a XML file, and we need to limit it.
TOMCAT_PASSWORD=$(getNewPassword 30)
TOMCATJMX_USER=${TOMCATJMX_USER:-tcjmx}
TOMCATJMX_PASSWORD=$(getNewComplexPassword 24)
DATADOGSQL_USER=${DATADOGSQL_USER:-dd_sql_ro}
DATADOGSQL_PASSWORD=$(getNewComplexPassword 24)

# store user/passwords: will not overwrite existing secrets
if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_ADMIN_USER"
then
	echo "iiq.admin.user already exists"
else
	echo "Storing IIQ adminitrator username as iiq.admin.user"
	SPADMIN_USER=$SPADMIN_USER $SMTOOL --set iiq.admin.user SPADMIN_USER
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_ADMIN_PASSWORD"
then
	echo "iiq.admin.password already exists"
else
	echo "Storing IIQ adminitrator password as iiq.admin.password"
	SPADMIN_PASSWORD=$SPADMIN_PASSWORD $SMTOOL --set iiq.admin.password SPADMIN_PASSWORD
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_DB_USER"
then
	echo "iiq.db.user already exists"
else
	echo "Storing IIQ database username as iiq.db.user"
	IIQDB_USER=$IIQDB_USER $SMTOOL --set iiq.db.user IIQDB_USER
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_DB_PASSWORD"
then
	echo "iiq.db.password already exists"
else
	echo "Storing IIQ database password as iiq.db.password"
	IIQDB_PASSWORD=$IIQDB_PASSWORD $SMTOOL --set iiq.db.password IIQDB_PASSWORD
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_PLUGINDB_USER"
then
	echo "iiq.plugindb.user already exists"
else
	echo "Storing IIQ plugin database username as iiq.plugindb.user"
	IIQPLUGINDB_USER=$IIQPLUGINDB_USER $SMTOOL --set iiq.plugindb.user IIQPLUGINDB_USER
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_PLUGINDB_PASSWORD"
then
	echo "iiq.plugindb.password already exists"
else
	echo "Storing IIQ plugin database password as iiq.plugindb.password"
	IIQPLUGINDB_PASSWORD=$IIQPLUGINDB_PASSWORD $SMTOOL --set iiq.plugindb.password IIQPLUGINDB_PASSWORD
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_TOMCAT_USER"
then
	echo "iiq.tomcat.user already exists"
else
	echo "Storing tomcat username as iiq.tomcat.user"
	TOMCAT_USER=$TOMCAT_USER $SMTOOL --set iiq.tomcat.user TOMCAT_USER
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_TOMCAT_PASSWORD"
then
	echo "iiq.tomcat.password already exists"
else
	echo "Storing tomcat password as iiq.tomcat.password"
	TOMCAT_PASSWORD=$TOMCAT_PASSWORD $SMTOOL --set iiq.tomcat.password TOMCAT_PASSWORD
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_TOMCATJMX_USER"
then
	echo "iiq.tomcatjmx.user already exists"
else
	echo "Storing tomcat-jmx username as iiq.tomcatjmx.user"
	TOMCATJMX_USER=$TOMCATJMX_USER $SMTOOL --set iiq.tomcatjmx.user TOMCATJMX_USER
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_TOMCATJMX_PASSWORD"
then
	echo "iiq.tomcatjmx.password already exists"
else
	echo "Storing tomcat-jmx password as iiq.tomcatjmx.password"
	TOMCATJMX_PASSWORD=$TOMCATJMX_PASSWORD $SMTOOL --set iiq.tomcatjmx.password TOMCATJMX_PASSWORD
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_DATADOGSQL_USER"
then
	echo "iiq.datadogsql.user already exists"
else
	echo "Storing datadog username as iiq.datadogsql.user"
	DATADOGSQL_USER=$DATADOGSQL_USER $SMTOOL --set iiq.datadogsql.user DATADOGSQL_USER
fi

if echo $OLD_SECRETS | grep -wq "SECRET_IIQ_DATADOGSQL_PASSWORD"
then
	echo "iiq.datadogsql.password already exists"
else
	echo "Storing datadog sql password as iiq.datadogsql.password"
	DATADOGSQL_PASSWORD=$DATADOGSQL_PASSWORD $SMTOOL --set iiq.datadogsql.password DATADOGSQL_PASSWORD
fi

