#!/usr/bin/env python

'''
Ansible inventory script for IIQ CMS AWS cloud customer environments.
'''

'''
TODO:
    add command line arguments (argparse)
        --list
        --host
        region
        customer
        environment
    test db access info (ie: non-accessbile host)
    test against adhoc environment
    test against rackspace environment
    handle aws creds from secrets
    ? ability to assume a role
    ? gather route53 info (hostnames, domain names)
'''

'''
options/arguments
    REGION
    CUSTOMER
    ENV
    PROFILE?
    ROLE?

returns:
    inventory in JSON format, including IP address and groups.
    groups are: hidden, public, ui, task, web, bastion, dbs.
Public hosts have external IP addrs, otherwise the host is hidden.
The uis, tasks and bastions hosts are distinguished by 'type' tag.
The db host is not a real host but a holder that contains endpoint, port
and username for db access.
'''

import os
import argparse
import boto3
import json
from datetime import date, datetime


def parse_cli_args():
    """ Command line args """
    parser = argparse.ArgumentParser(description="Ansible dynamic inventory for IIQ CMS AWS customer environment")
    parser.add_argument('--list', action='store_true', default=True,
                        help='List instances (default: True)')
    parser.add_argument('--host', action='store',
                        help='Get info about specific host')
    parser.add_argument('--customer', '-c', action='store',
                        default=os.getenv('CUSTOMER'),
                        help='Name of customer')
    parser.add_argument('--env', '-environment', '-e', action='store', dest='env',
                        default=os.getenv('ENV'),
                        help='Name of environment for customer')
    parser.add_argument('--role', action='store',
                        default=os.getenv('AWS_CUSTOMER_ROLE'),
                        help='AWS IAM role to assume')
    parser.add_argument('--profile', '-p', action='store',
                        help='AWS credentials profile to use')
    parser.add_argument('--region', '-r', action='store',
                        help='AWS region for customer environment')
    args = parser.parse_args()
    return args


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError ("Type %s not serializable" % type(obj))


def match_filters(resource, filters, tags=None):
    """
    For stupid API calls that don't do filtering, this function will
    return True if the resource matches all of the filters.  If the filter
    name begins with "tag", it will be matched to the tags parameter, else 
    it will be matched to an attribute of the resource.
    Format for filters and tags is same as EC2 api calls.
    Modified to match tag keys and values as case-insensitive.
    """
    if tags is None:
        tags = resource.get('Tags', [])
    for filter in filters:
        matched = False
        fvals = [v.lower() for v in filter['Values']]
        if filter['Name'] == "tag":
            # match tag name only
            matched = any(t['Key'].lower() in fvals for t in tags)
        elif filter['Name'].startswith("tag:"):
            tagName = filter['Name'].split(":", 1)[1].lower()
            matched = any(t['Key'].lower() == tagName and t['Value'].lower() in fvals for t in tags)
        else:
            # match resource attribute
            matched = filter['Name'] in resource and resource[filter['Name']] in filter['Values']
        if not matched:
            # all filters must have a match
            return False
    # all filters had a match
    return True

def get_ec2_info(customer, environment, client_args, inventory):
    """ get the inventory info for ec2 instances """
    ec2 = boto3.client('ec2', **client_args)
    # possible filters: environment, customer, product, "cms", "iiq"
    aws_filters = [
        { 'Name':'instance-state-name', 'Values':['running'] }
    ]
    tag_filters = [
        { 'Name':'tag:Environment', 'Values':[environment] },
        { 'Name':'tag:Customer', 'Values':[customer] }
    ]
    resp = ec2.describe_instances(Filters=aws_filters)

    for r in resp['Reservations']:
        for i in r['Instances']:
            if not match_filters(resource=i, filters=tag_filters):
                continue
            group1 = ""
            group2 = ""
            if 'PublicIpAddress' in i:
                addr = i['PublicIpAddress']
                group2 = 'public'
            else:
                addr = i['PrivateIpAddress']
                group2 = 'hidden'
            for t in i['Tags']:
                if t['Key'].lower() == "Name".lower():
                    name = t['Value']
                if t['Key'].lower() == "Type".lower():
                    group1 = t['Value'].lower() + "s"
            if group1 == "bastions":
                name = "bastion"
            if group1 == "" and group2 == "":
                inventory['ungrouped']['hosts'].append(name)
            if group1 != "":
                inventory[group1]['hosts'].append(name)
            if group2 != "":
                inventory[group2]['hosts'].append(name)
            inventory['_meta']['hostvars'][name] = {
                'ansible_host': addr
            }

def get_rds_info(customer, environment, client_args, inventory):
    # get the aurora DB cluster info
    rds = boto3.client('rds', **client_args)
    resp = rds.describe_db_clusters()

    filters = [
        { 'Name':'Status', 'Values':['available'] },
        { 'Name':'tag:Environment', 'Values':[environment] },
        { 'Name':'tag:Customer', 'Values':[customer] }
    ]
    for c in resp['DBClusters']:
        # we have to get the tags separately and filter on them ourselves. Sigh.
        tagresp = rds.list_tags_for_resource(ResourceName=c['DBClusterArn'])
        if not match_filters(resource=c, filters=filters, tags=tagresp['TagList']):
            continue
        name = c['DBClusterIdentifier']
        inventory['dbs']['hosts'].append(name)
        inventory['_meta']['hostvars'][name] = {
            'ansible_host': c['Endpoint'],
            'db_addr': c['Endpoint'],
            'db_port': c['Port'],
            'db_user': c['MasterUsername'],
            'db_instance_id': c['DBClusterMembers'][0]['DBInstanceIdentifier']
        }

empty_inventory = {
    "_meta": {
        "hostvars": {}
    },
    "all": {
        "children": [
            "hidden",
            "public",
            "web",
            "tasks",
            "uis",
            "bastions",
#            "dbs",
            "ungrouped"
        ]
    },
    "ungrouped": {
        "hosts": []
    },
    "public": {
        "hosts": []
    },
    "hidden": {
        "hosts": []
    },
    "uis" : {
        "hosts": []
    },
    "tasks": {
        "hosts": []
    },
    "web": {
        "children": [
            "tasks",
            "uis"
        ]
    },
    "bastions": {
        "hosts": []
    },
    "dbs": {
        "hosts": []
    }
}

def get_inventory(customer, environment, client_args):
    inventory = empty_inventory
    if 'role' in client_args:
        role = client_args['role']
        del client_args['role']
        sts_client = boto3.client('sts', **client_args)
        aro = sts_client.assume_role(RoleArn=role, RoleSessionName="InvBuilderRole")
        creds = aro['Credentials']

        client_args['aws_access_key_id'] = creds['AccessKeyId']
        os.environ["AWS_ACCESS_KEY_ID"] =  creds['AccessKeyId']
        client_args['aws_secret_access_key'] = creds['SecretAccessKey']
        os.environ["AWS_SECRET_ACCESS_KEY"] =  creds['SecretAccessKey']
        client_args['aws_session_token'] = creds['SessionToken']
        os.environ["AWS_SESSION_TOKEN"] =  creds['SessionToken']
        os.environ.pop("AWS_CUSTOMER_ROLE", None)

    get_ec2_info(customer, environment, client_args, inventory)
    get_rds_info(customer, environment, client_args, inventory)
    return inventory

def main():
    args = parse_cli_args()

    client_args = {}
    if args.profile:
        client_args['profile_name'] = args.profile
    if args.region:
        client_args['region_name'] = args.region
    if args.role:
        client_args['role'] = args.role

    if args.customer is None:
        raise ValueError("customer name not found. Use --customer or set $CUSTOMER")
    if args.env is None:
        raise ValueError("environment name not found. Use --env or set $ENV")

    inventory = get_inventory(args.customer, args.env, client_args)

    if args.host:
        print(json.dumps(inventory['_meta']['hostvars'][args.host]))
    else:
        print(json.dumps(inventory))

if __name__ == '__main__':
    main()
