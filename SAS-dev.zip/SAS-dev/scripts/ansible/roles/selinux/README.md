Role Name
========

Disables selinux in CentOS

Author Information
------------------

Fernanda Martins (flmmartins@gmail.com)
LinkedIn: https://www.linkedin.com/in/flmmartins
