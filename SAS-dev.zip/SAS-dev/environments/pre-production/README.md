# Template overview
This environment folder "template" is a template that should be copied into a new folder at the same level. Don't modify it in-place, as this may cause merge conflicts as you grow out your repo.

For example, copy `environments/template` to a new folder name like `environments/test` that represents the environment you want to build for. Then adjust your property files for your `test` environment. When ready to build, change directory into the `environments/test` folder and run the `build.sh` there. This will establish which files are used to control the build.
Example copy command: `cp -R environments/template environments/test`

## Where's the target or host prefix for property files?
Unlike SSB or variants, there is no target environment prefix on files. Instead, the folder name (and the `build.sh` inside that folder) determines the "target" in the sense that the files for Ant and token replacement elements are all contained in a single folder for the environment. You must run the `build.sh` while your present working directory is set to your desired environment sub-folder. In addition, there is no use for `SP_TARGET` or host-specific build/target properties in this Ant script setup.

## target.env file
The file `target.env` contains some environment variables used across tools (including ant) in the build pipeline.  These variables are referenced in properties files as `${env.NAME}`. Most of the build scripts in the repo will automatically export `target.env` before performing a task.

## build.secret.properties and target.secret.properties
During the build process secrets are exported as environment variables.  You can override this by changing the `secret.*` properties in these file, for example when using a sandbox.  The spsmtool will set the env vars for the secrets, and the properties by default must match what is exported by the tool.  To see a list of available secrets, run: `scripts/secrets/spsmtool.py --list`


## Procedure for Initial Build/Deployment

You will need:
  - cloned github repo for customer
  - credentials to access CMS AWS account, including region name
  - credentials to access CMS Customer AWS account, including region name
  - name of customer and environment, must match cloud resource tags

Steps:
  - copy `environment/template` to `environments/$ENV`
  - edit `target.env` and fill out
    - IIQ_VERSION
    - IIQ_PATCH_LEVEL
    - IIQ_EFIX_NAMES (if needed)
    - AWS_DEFAULT_REGION (for customer AWS account)
    - CUSTOMER
    - ENV
  - login to customer AWS console via RackSpace portal and manually enter cloud secrets from RackSpace. Be sure to include the `product`, `customer`, `Environment`, `scope` and `type` tags.  The required secrets are:
    - iiqcms/$CUSTOMER/$ENV/cloud.db.user
    - iiqcms/$CUSTOMER/$ENV/cloud.db.password
    - iiqcms/$CUSTOMER/$ENV/cloud.host.user
    - iiqcms/$CUSTOMER/$ENV/cloud.host.key.file
    - iiqcms/$CUSTOMER/$ENV/cloud.bastion.user
    - iiqcms/$CUSTOMER/$ENV/cloud.bastion.key.file
  - Set AWS credentials to CMS AWS account, including region
  - run `../../scripts/secrets/creds.sh` to generate initial iiq secrets and store them in SecretsManager.
  - run `./deploy.sh get-iiq-media-from-s3`
  - set AWS credentials to customer AWS account, including region
  - run `./build.sh pre-deploy`
  - run `./deploy.sh initial`
  - manually verify that IIQ is up and running in customer cloud environment

## How do I exclude files for certain environments?
See `environments/template/exclude/README.md` for more info.