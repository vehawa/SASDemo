# Exclude Files and web/src Folder Overrides
Formerly the `ignorefiles.properties` pattern, the cloud pipeline Ant iteration contains several exclude files for various operations.
Like the old SSB, these still handle file copy, token replacement, and import exclusions for XML files (e.g. `exclude.xml.properties`). 
In addition, we have support for environment-specific binary (`src`/`web`) and non-binary (`web`) overrides during copy and compile operations.

The project-level `web` and `src` folders represent global files for copy and compilation, respectively.
Each environment-specific folder under `environments` should have its own `web` and `src` folders. These are created as empty folders as part of the `main` target if none exist.
These environment-specific folders (if no override is necessary) can happily sit as empty folders. Any files placed here that match in name with global files will override what is in the global, related folder and "win" with respect to appearing in the `build/extract` area. 
Furthermore, if an environment-specific file has no global match, it will still appear in `build/extract`.

The purpose here is to allow for merging and code promotion between pre-prod and master branches. 
Thus, if there is testing occurring for a specific binary in another branch, we can override/ignore specific files per environment.
Only the most common elements should be part of the global `web` and `src` folders at the project root level.

Each exclude file starts as a blank/empty file in the template; this implies nothing is excluded from the global or environment-specific areas by default for `web`, `src`, or `config`.

## Exclude File Syntax and Examples
For the complete guide, see: https://ant.apache.org/manual/Types/fileset.html or https://ant.apache.org/manual/Tasks/javac.html.

Here are some highlights:

* Each line is a pattern for ignoring files in a particular `fileset` type or `javac` task during file copy, token replacement, or compilation operations.
	* These types/tasks have an `excludesfile` setting that is used to support the exclude file feature.
* One file name/pattern should be specified per line.
* Use a forward slash (`/`) as a path separator in all cases.
* The `#` signs are used to signify comments; any blank lines should be commented out.
* You can use wildcard operators like `*` in the files grab patterns of files.
* Consider that patterns used are used with a `fileset` type or `javac` task that are case-sensitive; your patterns for exclusion should also be case-sensitive.

### exclude.xml.properties
Used for excluding files in the `config`, `build/extract/WEB-INF/config/custom` during copy, token replacement, and import actions (via `build-inits` custom Ant task).
This is useful if you have template or other files in XML that should not be imported or copied to the `WEB-INF/config/custom` area.

Examples like this exclude XML from import operations (note the custom prefix that is build/extract relative):
* `custom/Application/Application-AD-Partner.xml`
* `custom/Workflow/Workflow-QuickTermination.xml`

Examples like this exclude from import AND copy operations (note they are just more aggressive search patterns):
* `Application/Application-AD-Partner.xml`
* `Workflow/Workflow-QuickTermination.xml`

### exclude.web.global.properties
Used for excluding files in the `web` directory at the project root during copy operations.

Example to exclude a specific jar file in the lib area:
* `WEB-INF/lib/exlude-this-jar.jar`

### exclude.web.env.properties
Used for excluding files in the `web` directory at the environment level during copy operations.
Syntax for this would be the same as `exclude.web.global.properties` since the relative pathing elements are the same.

### exclude.src.global.properties
Used for excluding files in the `src` directory at the project root during compile operations.

Example to exclude a specific java file:
* `mydir/Class1.java`

### exclude.src.env.properties
Used for excluding files in the `src` directory at the environment level during compile operations.
Syntax for this would be the same as `exclude.src.global.properties` since the relative pathing elements are the same.