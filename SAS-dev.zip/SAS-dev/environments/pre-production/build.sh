#!/bin/sh

beginUTC=$(date -u)
echo ""
echo "==>begin build script at $(date) [$beginUTC]"
echo ""

#project root relative to this shell script; changing this makes all other relative paths in this shell script update
#in this case going up 3 dirs from the build.sh gets us to the top of the repo/project
projectRoot="../.."

#path to ant shell script; this will vary based on your directory structure
antJar="$projectRoot/lib/ant/1.10.5/bin/ant"

#We need to adjust random number generation to the less-secure urandom; without this, it takes a long time for jvm to spin up when /dev/random is used
#note there are some references for java.security.egd in the ant xml files where JVMs are created
#https://stackoverflow.com/questions/43777075/java-sql-sqlexception-i-o-error-connection-reset-in-linux-server
#http://ruleoftech.com/2016/avoiding-jvm-delays-caused-by-random-number-generation
#https://bugs.java.com/view_bug.do?bug_id=6202721 -> for note about why we have a "." in the path here
jvmegd="-Djava.security.egd=file:/dev/./urandom"

#i like the color logger for ant, but some of the colors just are too dark or light to see properly; leaving here as example, but we likely won't use it much
#if you want to use it, throw in "-logger $colorLogger" to the command
#https://ant.apache.org/manual/listeners.html
#colorLogger="org.apache.tools.ant.listener.AnsiColorLogger"

antContribLib="$projectRoot/lib/ant-contrib/1.0b3/ant-contrib-1.0b3.jar"

#this is our entry point for ant, as we don't use a default "build.xml" and need to specifcy a build file to run
antFile="$projectRoot/scripts/ant/ant-core.xml"

#spit out some file pathing hints
echo "running $antJar"
currDir="$(pwd)"
echo "current directory is $currDir"

# import some environment variables that we might need
set -a
. ./target.env
set +a

# location of the secrets manager tool that we wrap the ant command with
# skip if first argument is -S
if [ "$1" == "-S" ]
then
	SMTool=""
	shift
else
	SMTool=$projectRoot/scripts/secrets/spsmtool.py
	echo "wrapping ant in $SMTool"
fi

#here we actually run our command...more info in the ant manual about command line options
#note "$@" means 'pass in the args sent to the bash script onto ant'
#this is how we can do things like './build.sh main' ... 'main' gets passed as a target call to ant!
#finally, remember you can always override various ant properties using -D<ant.property.name>=<my.value> (use this after targets!)
#https://ant.apache.org/manual/running.html#commandline
$SMTool "$antJar" -lib "$antContribLib" -f "$antFile" $@ $jvmegd

if [ $? -eq 0 ]; then
	endUTC=$(date -u)
	echo ""
	echo "==>SUCCESS! end build script at $(date) [$endUTC]"
	echo ""
else
	echo ""
	echo "==>ERROR! end build script at $(date) [$endUTC]"
	echo ""
	exit 100 #we want to fail this so builds (esp. remote ones) don't continue
fi
