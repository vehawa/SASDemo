#!/bin/sh

# run ansible playbook for us.
# deploy.sh [-S] playbook [options]
# -S: do not get secrets (doesn't run spsmtool)
# if target.yml file exists, use that for variables
# options are added to ansible-playbook command. This can include -e to add vars.

# ./deploy.sh <playbook>
# translates to "../../scripts/secrets/spsmtool.py ansible-playbook -i ../../scripts/ansible/aws.py ../../scripts/ansible/<playbook>.yml"
# TODO: handle passing other args to ansible.

beginUTC=$(date -u)
echo ""
echo "==>begin deploy playbook at $(date) [$beginUTC]"
echo ""

#project root relative to this shell script; changing this makes all other relative paths in this shell script update
#in this case going up 3 dirs from the build.sh gets us to the top of the repo/project
projectRoot="../.."

# location of the secrets manager tool that we wrap the ansible command with
# skip if first arg is -S
if [ "$1" == "-S" ]
then
	SMTool=""
	shift
	set -a
	. ./target.env
	set +a
else
	SMTool=$projectRoot/scripts/secrets/spsmtool.py
fi

# location of dynamic inventory file
InventoryFile=$projectRoot/scripts/ansible/aws.py

# playbook expanded name
Playbook=$projectRoot/scripts/ansible/${1}.yml
shift

if [ -f ./target.yml ]
then
	OPTS="-e @target.yml $@"
else
	OPTS=$@
fi

#spit out some file pathing hints
echo "running $SMTool ansible-playbook -i $InventoryFile $OPTS $Playbook"
currDir="$(pwd)"
echo "current directory is $currDir"

# target.env will be automatically imported by SMTool.

#here we actually run our command
# the ANSIBLE_RETRY_FILES_ENABLED env var stops ansible from spewing out
# retry files when there is an error in a playbook.
ANSIBLE_RETRY_FILES_ENABLED=0 $SMTool ansible-playbook -i $InventoryFile $OPTS $Playbook

if [ $? -eq 0 ]; then
	endUTC=$(date -u)
	echo ""
	echo "==>SUCCESS! end deploy playbook at $(date) [$endUTC]"
	echo ""
else
	echo ""
	echo "==>ERROR! end deploy playbook at $(date) [$endUTC]"
	echo ""
	exit 100 #we want to fail this so builds (esp. remote ones) don't continue
fi
