https://github.com/svn2github/BeanShell2 -> this is what iiq 7.2 and similar use, as they rely on bsh-2.1.8.jar
beanshell2 is a fork of original beanshell. as of 2018-09-13 (Thu), the download links for the 2.1.8 version are broken.
this is the version that does generics (yay!).


https://github.com/beanshell/beanshell -> the original beanshell migrated to github. the 2.0b6 version is the latest here as of 2018-09-13 (Thu), but it won't do generics (yuck).

